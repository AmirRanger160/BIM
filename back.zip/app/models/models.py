from sqlalchemy import Column, Integer, String, Text, DateTime, Boolean, Float, ForeignKey
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import relationship
from datetime import datetime

Base = declarative_base()


class User(Base):
    """Admin user model."""
    __tablename__ = "users"
    
    id = Column(Integer, primary_key=True, index=True)
    username = Column(String(255), unique=True, index=True, nullable=False)
    email = Column(String(255), unique=True, index=True, nullable=False)
    hashed_password = Column(String(255), nullable=False)
    is_admin = Column(Boolean, default=False)
    is_active = Column(Boolean, default=True)
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)


class Service(Base):
    """Service model for BIM and Surveying services."""
    __tablename__ = "services"
    
    id = Column(Integer, primary_key=True, index=True)
    # New bilingual fields
    title_en = Column(String(255), nullable=True, index=True)
    title_fa = Column(String(255), nullable=True)
    description_en = Column(Text, nullable=True)
    description_fa = Column(Text, nullable=True)
    # Old fields for backward compatibility
    title = Column(String(255), nullable=True, index=True)
    description = Column(Text, nullable=True)
    # Common fields
    category = Column(String(50), nullable=False, index=True)  # "BIM" or "Surveying"
    image_url = Column(String(500), nullable=True)
    software_tools = Column(String(500), nullable=True)  # Comma-separated list
    created_at = Column(DateTime, default=datetime.utcnow, index=True)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)


class TeamMember(Base):
    """Team member model."""
    __tablename__ = "team_members"
    
    id = Column(Integer, primary_key=True, index=True)
    name_en = Column(String(255), nullable=False)
    name_fa = Column(String(255), nullable=True)
    position_en = Column(String(255), nullable=True)
    position_fa = Column(String(255), nullable=True)
    email = Column(String(255), nullable=True, index=True)
    phone = Column(String(20), nullable=True)
    image_url = Column(String(500), nullable=True)
    bio_en = Column(Text, nullable=True)
    bio_fa = Column(Text, nullable=True)
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)


class Certificate(Base):
    """Certificate model."""
    __tablename__ = "certificates"
    
    id = Column(Integer, primary_key=True, index=True)
    title_en = Column(String(255), nullable=False)
    title_fa = Column(String(255), nullable=True)
    image_url = Column(String(500), nullable=True)
    description_en = Column(Text, nullable=True)
    description_fa = Column(Text, nullable=True)
    issue_date = Column(String(50), nullable=True)
    expiry_date = Column(String(50), nullable=True)
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)


class License(Base):
    """License model."""
    __tablename__ = "licenses"
    
    id = Column(Integer, primary_key=True, index=True)
    title_en = Column(String(255), nullable=False)
    title_fa = Column(String(255), nullable=True)
    image_url = Column(String(500), nullable=True)
    description_en = Column(Text, nullable=True)
    description_fa = Column(Text, nullable=True)
    issue_date = Column(String(50), nullable=True)
    issue_authority = Column(String(255), nullable=True)
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)


class ContactSubmission(Base):
    """Contact form submission model."""
    __tablename__ = "contact_submissions"
    
    id = Column(Integer, primary_key=True, index=True)
    name = Column(String(255), nullable=False, index=True)
    phone = Column(String(20), nullable=False)
    email = Column(String(255), nullable=False, index=True)
    message = Column(Text, nullable=False)
    status = Column(String(50), default="new", index=True)  # new, read, replied, archived
    ip_address = Column(String(50), nullable=True)
    user_agent = Column(String(500), nullable=True)
    submitted_at = Column(DateTime, default=datetime.utcnow, index=True)


class CompanyInfo(Base):
    """Company information model."""
    __tablename__ = "company_info"
    
    id = Column(Integer, primary_key=True, index=True)
    name = Column(String(255), nullable=False)
    description_en = Column(Text, nullable=False)
    description_fa = Column(Text, nullable=True)
    founded_year = Column(Integer, nullable=True)
    headquarters_location = Column(String(255), nullable=True)
    phone = Column(String(20), nullable=True)
    email = Column(String(255), nullable=True)
    address_city = Column(String(100), nullable=True)
    address_country = Column(String(100), nullable=True)
    total_employees = Column(Integer, nullable=True)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)


class Statistics(Base):
    """Statistics/metrics model."""
    __tablename__ = "statistics"
    
    id = Column(Integer, primary_key=True, index=True)
    annual_projects = Column(Integer, default=1000)
    service_types = Column(Integer, default=9)
    employees = Column(Integer, default=90)
    satisfied_clients = Column(Integer, default=100)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)


class Project(Base):
    """Project portfolio model."""
    __tablename__ = "projects"
    
    id = Column(Integer, primary_key=True, index=True)
    title_en = Column(String(255), nullable=False, index=True)
    title_fa = Column(String(255), nullable=True)
    description_en = Column(Text, nullable=False)
    description_fa = Column(Text, nullable=True)
    image_url = Column(String(500), nullable=True)
    archive_url = Column(String(500), nullable=True)
    iframe_url = Column(String(500), nullable=True)
    category = Column(String(50), nullable=True, index=True)  # e.g., "BIM", "Surveying"
    order = Column(Integer, default=0)  # For ordering in display
    is_featured = Column(Boolean, default=False)
    created_at = Column(DateTime, default=datetime.utcnow, index=True)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)


class Article(Base):
    """Article/Blog post model."""
    __tablename__ = "articles"
    
    id = Column(Integer, primary_key=True, index=True)
    title_en = Column(String(255), nullable=False, index=True)
    title_fa = Column(String(255), nullable=True)
    slug = Column(String(255), unique=True, nullable=False, index=True)
    summary_en = Column(Text, nullable=False)
    summary_fa = Column(Text, nullable=True)
    content_en = Column(Text, nullable=False)
    content_fa = Column(Text, nullable=True)
    image_url = Column(String(500), nullable=True)
    tags = Column(String(500), nullable=True)  # Comma-separated tags
    category = Column(String(100), nullable=True, index=True)
    author = Column(String(255), nullable=True)
    is_published = Column(Boolean, default=True, index=True)
    publish_date = Column(DateTime, default=datetime.utcnow, index=True)
    created_at = Column(DateTime, default=datetime.utcnow, index=True)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    # Relationship to article images
    images = relationship("ArticleImage", back_populates="article", cascade="all, delete-orphan")


class ArticleImage(Base):
    """Model for images embedded within article content."""
    __tablename__ = "article_images"
    
    id = Column(Integer, primary_key=True, index=True)
    article_id = Column(Integer, ForeignKey("articles.id"), nullable=False, index=True)
    image_url = Column(String(500), nullable=False)
    caption_en = Column(Text, nullable=True)
    caption_fa = Column(Text, nullable=True)
    alt_text_en = Column(String(500), nullable=True)
    alt_text_fa = Column(String(500), nullable=True)
    order = Column(Integer, default=0)  # For ordering images in article
    created_at = Column(DateTime, default=datetime.utcnow, index=True)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    # Relationship back to article
    article = relationship("Article", back_populates="images")
